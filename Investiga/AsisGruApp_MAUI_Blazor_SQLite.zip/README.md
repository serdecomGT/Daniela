# AsisGru – aplicación móvil MAUI + Blazor + SQLite

Proyecto base funcional construido a partir del **Plan para el desarrollo de AsisGru**.

## Tecnologías
- C#
- .NET MAUI
- Blazor Hybrid
- SQLite (`SQLite-net-pcl`)
- CSS propio para tema claro/oscuro

## Módulos implementados
1. Configuración del grupo
2. Gestión de participantes
3. Gestión de categorías
4. Gestión de actividades
5. Registro de asistencia
6. Consultas y reportes

## Reglas del plan implementadas
- Las cinco entidades de negocio son: Grupo, Participante, Categoría de actividad, Actividad y Asistencia.
- Un grupo tiene participantes y actividades.
- Una categoría contiene actividades.
- Una actividad pertenece a una categoría y a un grupo.
- Asistencia relaciona Participante + Actividad.
- SQLite funciona localmente.
- El teléfono del participante es obligatorio en el formulario.
- No se permite duplicar la asistencia de un participante en la misma actividad.
- Los participantes pueden desactivarse para conservar su historial.
- Los reportes trabajan con rango de fechas.
- Se incluyen consultas por actividad, categoría, general y resumen por categoría.
- Se calcula la diferencia entre asistencias totales y participantes únicos por categoría.
- El tema inicial se toma del tema del dispositivo.
- El usuario puede alternar manualmente entre tema claro y oscuro.
- La interfaz usa la paleta de las imágenes entregadas.

## Abrir en Visual Studio
1. Instala Visual Studio 2022 con la carga de trabajo **Desarrollo de aplicaciones móviles con .NET**.
2. Abre `AsisGruApp.csproj`.
3. Restaura los paquetes NuGet.
4. Selecciona **Windows Machine** o un emulador/dispositivo Android.
5. Ejecuta con F5.

## Nota
El proyecto apunta a `net9.0`. Si tu instalación de Visual Studio tiene otra versión de .NET MAUI, puedes cambiar los `TargetFrameworks` del `.csproj` a la versión que tengas instalada.

## Base de datos
El archivo `asisgru.db3` se crea automáticamente en `FileSystem.AppDataDirectory` la primera vez que se ejecuta la aplicación.

## Estructura
- `Models/`: entidades y modelos de reportes.
- `Data/`: creación y configuración de SQLite.
- `Services/`: acceso a datos, reglas y reportes.
- `Pages/`: las seis áreas principales.
- `Shared/`: menú y diseño general.
- `wwwroot/`: CSS, JavaScript y logotipo.
