# AsisGru – aplicación móvil MAUI + Blazor + SQLite

Proyecto base funcional construido a partir del **Plan para el desarrollo de AsisGru**, actualizado para **.NET 10 + .NET MAUI 10 + Blazor Hybrid + SQLite**.

## Tecnologías
- C#
- .NET MAUI
- Blazor Hybrid
- SQLite (`SQLite-net-pcl`)
- CSS propio para tema claro/oscuro

## Módulos implementados
1. Configuración del grupo
2. Gestión de participantes
3. Gestión de categorías
4. Gestión de actividades
5. Registro de asistencia
6. Consultas y reportes

## Reglas del plan implementadas
- Las cinco entidades de negocio son: Grupo, Participante, Categoría de actividad, Actividad y Asistencia.
- Un grupo tiene participantes y actividades.
- Una categoría contiene actividades.
- Una actividad pertenece a una categoría y a un grupo.
- Asistencia relaciona Participante + Actividad.
- SQLite funciona localmente.
- El teléfono del participante es obligatorio en el formulario.
- No se permite duplicar la asistencia de un participante en la misma actividad.
- Los participantes pueden desactivarse para conservar su historial.
- Los reportes trabajan con rango de fechas.
- Se incluyen consultas por actividad, categoría, general y resumen por categoría.
- Se calcula la diferencia entre asistencias totales y participantes únicos por categoría.
- El tema inicial se toma del tema del dispositivo.
- El usuario puede alternar manualmente entre tema claro y oscuro.
- La interfaz usa la paleta de las imágenes entregadas.

## Abrir en Visual Studio
1. Instala una versión de Visual Studio compatible con **.NET 10 y .NET MAUI 10**, con la carga de trabajo **Desarrollo de aplicaciones móviles con .NET**.
2. Abre `AsisGruApp.csproj`.
3. Restaura los paquetes NuGet.
4. Selecciona **Windows Machine** o un emulador/dispositivo Android.
5. Ejecuta con F5.

## .NET 10
El proyecto apunta a `net10.0` y utiliza los TFM `net10.0-android`, `net10.0-ios`, `net10.0-maccatalyst` y `net10.0-windows10.0.19041.0`.

El archivo `global.json` solicita el SDK `10.0.100` y permite avanzar automáticamente a una versión de feature más reciente de .NET 10.

Para Android se establece como versión mínima de plataforma la API 24, siguiendo la recomendación de actualización para proyectos MAUI en .NET 10.

Para compilar iOS desde Windows se requiere un Mac conectado para el proceso de compilación de iOS.

## Base de datos
El archivo `asisgru.db3` se crea automáticamente en `FileSystem.AppDataDirectory` la primera vez que se ejecuta la aplicación.

## Estructura
- `Models/`: entidades y modelos de reportes.
- `Data/`: creación y configuración de SQLite.
- `Services/`: acceso a datos, reglas y reportes.
- `Pages/`: las seis áreas principales.
- `Shared/`: menú y diseño general.
- `wwwroot/`: CSS, JavaScript y logotipo.
